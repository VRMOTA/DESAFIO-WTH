USE AdventureWorksDW2022;
GO

SELECT DB_NAME() AS BaseRestaurada, SERVERPROPERTY('ProductVersion') AS VersionSQL;

SELECT N'FactInternetSales' AS Tabla, COUNT_BIG(*) AS Filas FROM dbo.FactInternetSales
UNION ALL SELECT N'FactResellerSales', COUNT_BIG(*) FROM dbo.FactResellerSales
UNION ALL SELECT N'DimDate', COUNT_BIG(*) FROM dbo.DimDate
UNION ALL SELECT N'DimProduct', COUNT_BIG(*) FROM dbo.DimProduct
UNION ALL SELECT N'DimProductSubcategory', COUNT_BIG(*) FROM dbo.DimProductSubcategory
UNION ALL SELECT N'DimProductCategory', COUNT_BIG(*) FROM dbo.DimProductCategory
UNION ALL SELECT N'DimSalesTerritory', COUNT_BIG(*) FROM dbo.DimSalesTerritory;

SELECT N'Internet' AS Canal, MIN(d.FullDateAlternateKey) AS PrimerPedido,
       MAX(d.FullDateAlternateKey) AS UltimoPedido, SUM(f.OrderQuantity) AS Unidades,
       SUM(f.SalesAmount) AS Ventas, SUM(f.TotalProductCost) AS Costo
FROM dbo.FactInternetSales AS f
JOIN dbo.DimDate AS d ON d.DateKey = f.OrderDateKey
UNION ALL
SELECT N'Revendedor', MIN(d.FullDateAlternateKey), MAX(d.FullDateAlternateKey),
       SUM(f.OrderQuantity), SUM(f.SalesAmount), SUM(f.TotalProductCost)
FROM dbo.FactResellerSales AS f
JOIN dbo.DimDate AS d ON d.DateKey = f.OrderDateKey;
