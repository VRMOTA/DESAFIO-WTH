USE AdventureWorksDW2022;
GO

-- A. Ranking anual por unidades. Una fila por categoría y otra por subcategoría.
WITH VolumenAnual AS (
    SELECT t.Anio, p.Categoria, p.Subcategoria,
           GROUPING(p.Subcategoria) AS EsCategoria, SUM(v.Unidades) AS Unidades,
           SUM(v.Ventas) AS Ventas
    FROM dbo.vDP2_Ventas AS v
    JOIN dbo.vDP2_Tiempo AS t ON t.DateKey = v.OrderDateKey
    JOIN dbo.vDP2_Producto AS p ON p.SKU = v.SKU
    GROUP BY GROUPING SETS ((t.Anio, p.Categoria), (t.Anio, p.Categoria, p.Subcategoria))
)
SELECT Anio, CASE EsCategoria WHEN 1 THEN N'Categoría' ELSE N'Subcategoría' END AS Nivel,
       Categoria, Subcategoria, Unidades, Ventas,
       DENSE_RANK() OVER (PARTITION BY Anio, EsCategoria ORDER BY Unidades DESC) AS Puesto
FROM VolumenAnual
ORDER BY Anio, EsCategoria DESC, Puesto, Categoria, Subcategoria;

-- A. Tendencia trimestral por categoría y subcategoría.
SELECT t.Anio, t.NumeroTrimestre, p.Categoria, p.Subcategoria,
       SUM(v.Unidades) AS Unidades, SUM(v.Ventas) AS Ventas
FROM dbo.vDP2_Ventas AS v
JOIN dbo.vDP2_Tiempo AS t ON t.DateKey = v.OrderDateKey
JOIN dbo.vDP2_Producto AS p ON p.SKU = v.SKU
GROUP BY t.Anio, t.NumeroTrimestre, p.Categoria, p.Subcategoria
ORDER BY t.Anio, t.NumeroTrimestre, Unidades DESC, p.Categoria, p.Subcategoria;

-- B. Orden territorial por utilidad total y comparación entre los dos canales.
SELECT r.Territorio, SUM(v.Utilidad) AS UtilidadTotal,
       SUM(CASE WHEN v.CanalID = 1 THEN v.Ventas ELSE 0 END) AS VentasInternet,
       SUM(CASE WHEN v.CanalID = 2 THEN v.Ventas ELSE 0 END) AS VentasRevendedor,
       SUM(CASE WHEN v.CanalID = 1 THEN v.Utilidad ELSE 0 END) AS UtilidadInternet,
       SUM(CASE WHEN v.CanalID = 2 THEN v.Utilidad ELSE 0 END) AS UtilidadRevendedor,
       CAST(100.0 * SUM(v.Utilidad) / NULLIF(SUM(v.Ventas), 0) AS decimal(12, 2)) AS MargenPct
FROM dbo.vDP2_Ventas AS v
JOIN dbo.vDP2_Territorio AS r ON r.TerritorioID = v.TerritorioID
GROUP BY r.TerritorioID, r.Territorio
ORDER BY UtilidadTotal DESC, r.Territorio;

-- C. Mismos diez SKU del ranking global en los desgloses anual y trimestral.
WITH TopProductos AS (
    SELECT TOP (10) SKU, SUM(Utilidad) AS UtilidadGlobal
    FROM dbo.vDP2_Ventas
    GROUP BY SKU
    ORDER BY SUM(Utilidad) DESC, SKU
), Serie AS (
    SELECT p.SKU, t.Anio, t.NumeroTrimestre,
           SUM(v.Ventas) AS Ventas, SUM(v.Utilidad) AS Utilidad
    FROM TopProductos AS p
    JOIN dbo.vDP2_Ventas AS v ON v.SKU = p.SKU
    JOIN dbo.vDP2_Tiempo AS t ON t.DateKey = v.OrderDateKey
    GROUP BY GROUPING SETS ((p.SKU, t.Anio), (p.SKU, t.Anio, t.NumeroTrimestre))
)
SELECT DENSE_RANK() OVER (ORDER BY g.UtilidadGlobal DESC, g.SKU) AS Puesto,
       p.SKU, p.Producto, g.UtilidadGlobal, s.Anio, s.NumeroTrimestre, s.Ventas, s.Utilidad
FROM Serie AS s
JOIN TopProductos AS g ON g.SKU = s.SKU
JOIN dbo.vDP2_Producto AS p ON p.SKU = s.SKU
ORDER BY Puesto, s.Anio, s.NumeroTrimestre;
