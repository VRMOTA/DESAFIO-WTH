USE AdventureWorksDW2022;
GO

CREATE OR ALTER VIEW dbo.vDP2_ProductoOrigen AS
SELECT ProductKey,
       COALESCE(NULLIF(LTRIM(RTRIM(ProductAlternateKey)), N''), CONCAT(N'#', ProductKey)) AS SKU,
       EnglishProductName, ProductSubcategoryKey, EndDate
FROM dbo.DimProduct;
GO

CREATE OR ALTER VIEW dbo.vDP2_Producto AS
WITH Versiones AS (
    SELECT p.*,
           ROW_NUMBER() OVER (PARTITION BY SKU
               ORDER BY CASE WHEN EndDate IS NULL THEN 0 ELSE 1 END, EndDate DESC, ProductKey DESC) AS Version
    FROM dbo.vDP2_ProductoOrigen AS p
)
SELECT p.SKU, CONCAT(p.EnglishProductName, N' (', p.SKU, N')') AS Producto,
       COALESCE(c.EnglishProductCategoryName, N'Sin categoría') AS Categoria,
       COALESCE(s.EnglishProductSubcategoryName, N'Sin subcategoría') AS Subcategoria
FROM Versiones AS p
LEFT JOIN dbo.DimProductSubcategory AS s ON s.ProductSubcategoryKey = p.ProductSubcategoryKey
LEFT JOIN dbo.DimProductCategory AS c ON c.ProductCategoryKey = s.ProductCategoryKey
WHERE p.Version = 1;
GO

CREATE OR ALTER VIEW dbo.vDP2_Tiempo AS
SELECT DateKey, FullDateAlternateKey AS Fecha, CalendarYear AS Anio,
       CalendarQuarter AS NumeroTrimestre,
       CalendarYear * 10 + CalendarQuarter AS ClaveTrimestre,
       CONCAT(CalendarYear, N' T', CalendarQuarter) AS Trimestre
FROM dbo.DimDate;
GO

CREATE OR ALTER VIEW dbo.vDP2_Territorio AS
SELECT SalesTerritoryKey AS TerritorioID, SalesTerritoryCountry AS Pais,
       CONCAT(SalesTerritoryCountry, N' / ', SalesTerritoryRegion) AS Territorio
FROM dbo.DimSalesTerritory;
GO

CREATE OR ALTER VIEW dbo.vDP2_Canal AS
SELECT CanalID, Canal
FROM (VALUES (1, N'Internet'), (2, N'Revendedor')) AS canales(CanalID, Canal);
GO

CREATE OR ALTER VIEW dbo.vDP2_Ventas AS
WITH Lineas AS (
    SELECT 1 AS CanalID, SalesOrderNumber, SalesOrderLineNumber, OrderDateKey,
           ProductKey, SalesTerritoryKey, OrderQuantity, SalesAmount, TotalProductCost
    FROM dbo.FactInternetSales
    UNION ALL
    SELECT 2, SalesOrderNumber, SalesOrderLineNumber, OrderDateKey,
           ProductKey, SalesTerritoryKey, OrderQuantity, SalesAmount, TotalProductCost
    FROM dbo.FactResellerSales
)
SELECT f.CanalID, f.SalesOrderNumber, f.SalesOrderLineNumber, f.OrderDateKey,
       p.SKU, f.SalesTerritoryKey AS TerritorioID,
       CONVERT(int, f.OrderQuantity) AS Unidades, f.SalesAmount AS Ventas,
       f.TotalProductCost AS Costo, f.SalesAmount - f.TotalProductCost AS Utilidad
FROM Lineas AS f
JOIN dbo.vDP2_ProductoOrigen AS p ON p.ProductKey = f.ProductKey;
GO

-- Los conteos y los totales por canal deben coincidir con 01_exploracion.sql.
SELECT c.Canal, COUNT_BIG(*) AS Filas, SUM(v.Unidades) AS Unidades,
       SUM(v.Ventas) AS Ventas, SUM(v.Costo) AS Costo, SUM(v.Utilidad) AS Utilidad
FROM dbo.vDP2_Ventas AS v
JOIN dbo.vDP2_Canal AS c ON c.CanalID = v.CanalID
GROUP BY c.Canal;

-- Debe devolver cero si las dimensiones cubren todas las líneas de venta.
SELECT COUNT_BIG(*) AS VentasSinDimension
FROM dbo.vDP2_Ventas AS v
LEFT JOIN dbo.vDP2_Producto AS p ON p.SKU = v.SKU
LEFT JOIN dbo.vDP2_Tiempo AS t ON t.DateKey = v.OrderDateKey
LEFT JOIN dbo.vDP2_Territorio AS r ON r.TerritorioID = v.TerritorioID
LEFT JOIN dbo.vDP2_Canal AS c ON c.CanalID = v.CanalID
WHERE p.SKU IS NULL OR t.DateKey IS NULL OR r.TerritorioID IS NULL OR c.CanalID IS NULL;
